<?php include ('connectfit.php');?>
<?php


	session_start();



$fast_start=$_POST['fasttimes'];
$fast_end = $_POST['fasttimee'];

 $launch_start=$_POST['launchstart'];
$launch_end = $_POST['launchend'];
  $dinner_start=$_POST['dinnerstart'];
$dinner_end = $_POST['dinnerend'];
 
  
   $sql = "UPDATE timetable SET fast_time_start='$fast_start' ,fast_time_end='$fast_end',launch_time_start='$launch_start',launch_time_end='$launch_end',dinner_time_start='$dinner_start',dinner_time_end='$dinner_end' WHERE id=5";
  
  
	  
	  


if (mysqli_query($conn, $sql)) {
    echo "Record updated successfully";
	header ("location:admin_monday_detail.php");

} else {
    echo "Error updating record: " . mysqli_error($conn);
}

mysqli_close($conn);



?>