<?php include ('connectfit.php');?>
<?php
session_start();

$id=$_REQUEST['id'];



      $table_name=$_SESSION["admin_selected"]; 


	
$sql = "DELETE FROM $table_name WHERE id=$id";

if ($conn->query($sql) === TRUE) {
   // echo "Record deleted successfully"; 
   header ("location:admin_monday_detail.php");
} else {
    echo "Error deleting record: " . $conn->error;
}
	

$conn->close();

?>