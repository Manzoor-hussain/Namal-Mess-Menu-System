<?php 
include ('connectfit.php');



 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <link rel="stylesheet" href="fitstyle.css">


 <style  type="text/css">
    
	
	
 </style>
		
		 </head>

            <body>

 <div id="headertop1">
		<img id="logo" src="logo.png" width="120px" height="110px"></img>
		<text id="toptext">Namal College Mess Menu</text>
	
	</div>

<nav style="background-color:#183113;" class="navbar navbar-inverse">
  <div  style="margin-left:0px;"class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button> 
      
    </div>
  
   
    <div style="margin-left:0px;" class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" class="list-inline">
        <li style="color:red;margin-left:-60px;" class="active"><a href="home.php"><b>Home</b></a></li>
		
		
       
	
		
	
       
         <li><a href="menu.php"><b>Menu</b></a></li>
       
        <li><a href="contact_us.php"><b>Contact</b></a></li>
		 <li><a href="complain.php"><b>Complain</b></a></li>
      </ul>
	  <form class="navbar-form navbar-left">
      <div style="margin-left:200px;"class="input-group">
        <input type="text" class="form-control" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
	  
      <ul class="nav navbar-nav navbar-right">
        <li><a href="sign-in.php"><span class="glyphicon glyphicon-log-in"></span> <b>Login</b></a></li>
      </ul>
    </div>
  </div>
</nav>
<br><br><br>
 <?php
        session_start();

        if (!empty($_SESSION['error'])){
    ?>
    <div style="margin-left:40%; margin-right:40%;" class="alert alert-warning" role="alert"> 
    <?php
        echo $_SESSION['error'];
        unset($_SESSION['error']);
        }
    ?>
   </div>
   <?php
        //session_start();

        if (!empty($_SESSION['update'])){
    ?>
    <div style="margin-left:40%; margin-right:40%;" class="alert alert-warning" role="alert"> 
    <?php
        echo $_SESSION['update'];
        unset($_SESSION['update']);
        }
    ?>
   </div>
   
 <div class="container">
  <h2 style="margin-left:20%;">Log in</h2>
  <div style="margin-left:20%; margin-right:20%; background-color:#CDB99C;"  class="jumbotron">
    <div class="container text-center">
  <form class="form-inline" method="post" action="account_search.php" >
    <div class="form-group">
      <label for="email">User Name:</label>
      <input type="email" class="form-control"  name="email" placeholder="Ente Name/Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required
	  >
    </div>
	<br><br>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control"  name="password" placeholder="Enter password" required>
    </div>
	<br>
    <div class="checkbox">
      <label><input type="checkbox" name="remember" unchecked >Remember me</label>
    </div><br>
	<div class="form-group">
     
     <a <button href="forget.php" type="submit"  style="width:125px; height:21px;margin-left:40px;">Forget Password</button></a>
    </div><br><br><br>
    <button type="submit"  class="btn btn-default">Sign in</button>
  </form>
  </div>
  </div>
  </div>
  <br><br><br>
     

      
 
<br><br><br><br>
   
	<div id="footer">
		<div class="followcontact">
		 <b>FOLLOW US ON<b>
			
		</div>
		<div  class="followcontact">
		<b>CONTACT INFO<b>	
		</div>
		<br><br><br><br><br><br>
		
		<div class="followuson">
			<a href="https://www.google.com.pk/search?q=facebook+namal+knowledge+city&oq=face&aqs=chrome.4.69i60j69i59l2j69i60j69i59j69i60.11179j0j7&sourceid=chrome&ie=UTF-8">
			<img id="facebook" src="facebook-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://twitter.com/namaledu?lang=en">
			<img id="twitter" src="twitter-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://vimeo.com/82274882">
			<img id="vimeo" src="vimeo-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://www.instagram.com/p/BD_bXBbEnLj/">
			<img id="instagram" src="instagram-128.png" width="40px" height="40px"></img>
			</a>
		</div>
		
		<div class="contactinfo">
			<div id="universityinfo">
				<img id="universityimg" style="margin-left:27px; margin-bottom:10px;"src="university.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">Namal College Mianwali</text>	
			<div>
			<div id="homeinfo">
				<img id="homeimg"   style="margin-left:27px; margin-bottom:10px;" src="home-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">30 Km Talagang Road, Mianwali, 42250, Pakistan</text>	
			<div>
			<div id="phoneinfo">
				<img id="phoneimg"  style="margin-left:27px; margin-bottom:10px; " src="phone-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">+92 (459) 236995</text>	
			<div>
			<div id="mailinfo">
				<img id="mailimg"  style="margin-left:27px;" src="mail-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">+92 (459) 236995</text>	
			<div>
			
			
		</div>
	</div> 	



			 
			 
			 
			 
			 
			

</body>

</html>
