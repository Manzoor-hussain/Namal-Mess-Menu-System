 <!DOCTYPE html>
<?php 
include ('connectfit.php');


 session_start();

 ?>

<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>

 <link rel="stylesheet" href="fitstyle.css">
</head>
<body>
<?php
$email=$_POST['email'];
$password=$_POST['password'];

$sql="SELECT * FROM login WHERE id=1";
$query = mysqli_query($conn,$sql);

while($row_select= mysqli_fetch_array($query))
{



 $adminmail =$row_select['email']; 
   $password1=$row_select['password'];




}
   
  if($adminmail==$email && $password==$password1)
   {
	   $_SESSION["security"] ="manzoor";
	  
	header("location:home3.php");
   
	
   }
   else
   {
	  $_SESSION['error'] = 'Password and email Mismath';

   header("location:sign-in.php"); 
   }
			

  

?>
<script>

</script>	

     </body>
	 </html>