<?php 
include ('connectfit.php');



 ?>
<?php
 


//if(isset($_POST['submit'])){
//$selected_val = $_POST['time'];  // Storing Selected Value In Variable
//echo "You have selected :" .$selected_val;  // Displaying Selected Value
//}
$selected_val = $_POST['time']; 
$selected_day = $_POST['day']; 
 $item_name=$_POST['itemname'];
 $half_price=$_POST['halfprice'];
 $full_price=$_POST['fullprice'];
 
 
 if($selected_val=="BreakFast")
 {
	 
 
	$sql = "INSERT INTO $selected_day (item,food_time,half_price,full_price)
   VALUES ('$item_name','$selected_val', '$half_price','$full_price')";
  
  $result_insert=mysqli_query($conn,$sql);
	if($result_insert==true)
   {
	header("location:add_menu.php");
   }
  }
  else if($selected_val=="Launch")
 {
	 
 
	$sql = "INSERT INTO $selected_day(item_launch,food_time,half_price_launch,full_price_launch)
   VALUES ('$item_name','$selected_val', '$half_price','$full_price')";
  
  $result_insert=mysqli_query($conn,$sql);
	if($result_insert==true)
   {
	header("location:add_menu.php");
   }
  } 
   else if($selected_val=="Dinner")
 {
	 
 
	$sql = "INSERT INTO $selected_day (item_dinner,food_time,half_price_dinner,full_price_dinner)
   VALUES ('$item_name','$selected_val', '$half_price','$full_price')";
  
  $result_insert=mysqli_query($conn,$sql);
	if($result_insert==true)
   {
	header("location:add_menu.php");
   }
  } 
  else
	  echo "wrong";
 
?>