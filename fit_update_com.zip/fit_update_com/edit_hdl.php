<?php
include('conectdps.php');
//$id=$_REQUEST['id'];
$id=$_REQUEST['id'];
//$id=12;
$fname = $_POST['fname'];
$lname= $_POST['lname'];
 $email=$_POST['email'];
 $address=$_POST['address'];
  $check=$_POST['admin'];
  $clean="";
  $unclean="";
  if($check=="")
  {
	  $clean="C";
	  $unclean="";
  }
  else
   if($check=="NC"){
	   
	  $unclean="NC";
       $clean="";
  
  }
  else if($check=="C")
  {
	  $clean="";
	  $unclean="NC";
  }
$sql = "UPDATE orderbooking SET fname='$fname' ,lname='$lname' ,emails='$email' ,address='$address',clean='$clean' ,unclean='$unclean' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();



?>