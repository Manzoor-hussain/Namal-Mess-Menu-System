-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 20, 2018 at 07:19 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fit`
--

-- --------------------------------------------------------

--
-- Table structure for table `friday`
--

CREATE TABLE IF NOT EXISTS `friday` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `food_time` varchar(100) DEFAULT NULL,
  `half_price` int(3) DEFAULT NULL,
  `full_price` int(4) DEFAULT NULL,
  `item_launch` varchar(100) DEFAULT NULL,
  `half_price_launch` int(3) DEFAULT NULL,
  `full_price_launch` int(4) DEFAULT NULL,
  `item_dinner` varchar(100) DEFAULT NULL,
  `half_price_dinner` int(3) DEFAULT NULL,
  `full_price_dinner` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `friday`
--

INSERT INTO `friday` (`id`, `item`, `food_time`, `half_price`, `full_price`, `item_launch`, `half_price_launch`, `full_price_launch`, `item_dinner`, `half_price_dinner`, `full_price_dinner`) VALUES
(2, NULL, 'Launch', NULL, NULL, 'dal chana', 20, 30, NULL, NULL, NULL),
(3, NULL, 'Dinner', NULL, NULL, NULL, NULL, NULL, 'chicken Barani', 50, 75),
(4, 'paratha', 'BreakFast', 0, 20, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(159) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `password`) VALUES
(1, 'manzoor2015@namal.edu.pk', 'hussain');

-- --------------------------------------------------------

--
-- Table structure for table `monday`
--

CREATE TABLE IF NOT EXISTS `monday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `food_time` varchar(50) DEFAULT NULL,
  `half_price` int(3) DEFAULT NULL,
  `full_price` int(3) DEFAULT NULL,
  `item_launch` varchar(100) DEFAULT NULL,
  `half_price_launch` int(3) DEFAULT NULL,
  `full_price_launch` int(4) DEFAULT NULL,
  `item_dinner` varchar(200) DEFAULT NULL,
  `half_price_dinner` int(3) DEFAULT NULL,
  `full_price_dinner` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `monday`
--

INSERT INTO `monday` (`id`, `item`, `food_time`, `half_price`, `full_price`, `item_launch`, `half_price_launch`, `full_price_launch`, `item_dinner`, `half_price_dinner`, `full_price_dinner`) VALUES
(7, 'dal chana', 'Launch', 20, 30, 'dal chana', 20, 40, NULL, NULL, NULL),
(8, NULL, 'Dinner', NULL, NULL, NULL, NULL, NULL, 'chicken karai', 40, 85),
(9, 'Tea', 'BreakFast', 10, 40, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'dal chana', 'BreakFast', 10, 20, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 'h', 'BreakFast', 5, 10, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `saturday`
--

CREATE TABLE IF NOT EXISTS `saturday` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `food_time` varchar(100) DEFAULT NULL,
  `half_price` int(3) DEFAULT NULL,
  `full_price` int(4) DEFAULT NULL,
  `item_launch` varchar(100) DEFAULT NULL,
  `half_price_launch` int(3) DEFAULT NULL,
  `full_price_launch` int(4) DEFAULT NULL,
  `item_dinner` varchar(100) DEFAULT NULL,
  `half_price_dinner` int(3) DEFAULT NULL,
  `full_price_dinner` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `saturday`
--

INSERT INTO `saturday` (`id`, `item`, `food_time`, `half_price`, `full_price`, `item_launch`, `half_price_launch`, `full_price_launch`, `item_dinner`, `half_price_dinner`, `full_price_dinner`) VALUES
(1, 'Tea', 'BreakFast', 10, 20, NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, 'Launch', NULL, NULL, 'Alu Ghobhi', 20, 30, NULL, NULL, NULL),
(3, NULL, 'Dinner', NULL, NULL, NULL, NULL, NULL, 'chicken Barani', 50, 75);

-- --------------------------------------------------------

--
-- Table structure for table `sunday`
--

CREATE TABLE IF NOT EXISTS `sunday` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `food_time` varchar(100) DEFAULT NULL,
  `half_price` int(3) DEFAULT NULL,
  `full_price` int(4) DEFAULT NULL,
  `item_launch` varchar(100) DEFAULT NULL,
  `half_price_launch` int(3) DEFAULT NULL,
  `full_price_launch` int(4) DEFAULT NULL,
  `item_dinner` varchar(100) DEFAULT NULL,
  `half_price_dinner` int(3) DEFAULT NULL,
  `full_price_dinner` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `sunday`
--

INSERT INTO `sunday` (`id`, `item`, `food_time`, `half_price`, `full_price`, `item_launch`, `half_price_launch`, `full_price_launch`, `item_dinner`, `half_price_dinner`, `full_price_dinner`) VALUES
(1, 'Alu Paratha', 'BreakFast', 0, 20, NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, 'Launch', NULL, NULL, 'Alu chicken', 30, 50, NULL, NULL, NULL),
(4, NULL, 'Dinner', NULL, NULL, NULL, NULL, NULL, 'dal chana', 20, 30);

-- --------------------------------------------------------

--
-- Table structure for table `thursday`
--

CREATE TABLE IF NOT EXISTS `thursday` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `food_time` varchar(100) DEFAULT NULL,
  `half_price` int(3) DEFAULT NULL,
  `full_price` int(4) DEFAULT NULL,
  `item_launch` varchar(100) DEFAULT NULL,
  `half_price_launch` int(3) DEFAULT NULL,
  `full_price_launch` int(4) DEFAULT NULL,
  `item_dinner` varchar(100) DEFAULT NULL,
  `half_price_dinner` int(3) DEFAULT NULL,
  `full_price_dinner` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `thursday`
--

INSERT INTO `thursday` (`id`, `item`, `food_time`, `half_price`, `full_price`, `item_launch`, `half_price_launch`, `full_price_launch`, `item_dinner`, `half_price_dinner`, `full_price_dinner`) VALUES
(1, 'paratha', 'BreakFast', 10, 20, NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, 'Launch', NULL, NULL, 'chicken karai', 45, 70, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

CREATE TABLE IF NOT EXISTS `timetable` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `dinner_time_end` time(6) DEFAULT NULL,
  `fast_time_start` time(6) DEFAULT NULL,
  `fast_time_end` time(6) DEFAULT NULL,
  `launch_time_start` time DEFAULT NULL,
  `launch_time_end` time(6) DEFAULT NULL,
  `dinner_time_start` time(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `dinner_time_end`, `fast_time_start`, `fast_time_end`, `launch_time_start`, `launch_time_end`, `dinner_time_start`) VALUES
(1, NULL, NULL, NULL, '03:04:00', '05:54:00.000000', NULL),
(2, NULL, NULL, NULL, '03:04:00', '05:54:00.000000', NULL),
(3, NULL, NULL, NULL, '03:04:00', '05:54:00.000000', NULL),
(4, NULL, NULL, NULL, '03:04:00', '05:54:00.000000', NULL),
(5, '01:00:00.000000', '03:02:00.000000', '01:00:00.000000', '16:05:00', '01:00:00.000000', '01:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `tuesday`
--

CREATE TABLE IF NOT EXISTS `tuesday` (
  `id` int(7) NOT NULL AUTO_INCREMENT,
  `item` varchar(100) DEFAULT NULL,
  `food_time` varchar(100) DEFAULT NULL,
  `half_price` int(3) DEFAULT NULL,
  `full_price` int(4) DEFAULT NULL,
  `item_launch` varchar(100) DEFAULT NULL,
  `half_price_launch` int(3) DEFAULT NULL,
  `full_price_launch` int(4) DEFAULT NULL,
  `item_dinner` varchar(100) DEFAULT NULL,
  `half_price_dinner` int(3) DEFAULT NULL,
  `full_price_dinner` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tuesday`
--

INSERT INTO `tuesday` (`id`, `item`, `food_time`, `half_price`, `full_price`, `item_launch`, `half_price_launch`, `full_price_launch`, `item_dinner`, `half_price_dinner`, `full_price_dinner`) VALUES
(1, 'paratha', 'BreakFast', 10, 20, NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, 'Launch', NULL, NULL, 'chicken karai', 40, 65, NULL, NULL, NULL),
(3, NULL, 'Dinner', NULL, NULL, NULL, NULL, NULL, 'dal chana', 20, 30);

-- --------------------------------------------------------

--
-- Table structure for table `wenesday`
--

CREATE TABLE IF NOT EXISTS `wenesday` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `food_time` varchar(100) DEFAULT NULL,
  `item` varchar(100) DEFAULT NULL,
  `half_price` int(3) DEFAULT NULL,
  `full_price` int(4) DEFAULT NULL,
  `item_launch` varchar(100) DEFAULT NULL,
  `half_price_launch` int(3) DEFAULT NULL,
  `full_price_launch` int(4) DEFAULT NULL,
  `item_dinner` varchar(100) DEFAULT NULL,
  `half_price_dinner` int(3) DEFAULT NULL,
  `full_price_dinner` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `wenesday`
--

INSERT INTO `wenesday` (`id`, `food_time`, `item`, `half_price`, `full_price`, `item_launch`, `half_price_launch`, `full_price_launch`, `item_dinner`, `half_price_dinner`, `full_price_dinner`) VALUES
(1, 'BreakFast', 'paratha', 10, 20, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Launch', NULL, NULL, NULL, 'dal chana', 15, 20, NULL, NULL, NULL),
(3, 'Dinner', NULL, NULL, NULL, NULL, NULL, NULL, 'chicken karai', 45, 75);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
