<?php 
include ('connectfit.php');



 ?>


<?php
 
//include 'conect.php';
 
 
$name = $_POST['fname'];
 $email=$_POST['email'];
 $subject=$_POST['subject'];
 
  $message=$_POST['complain'];
 $current=date("Y-m-d");

	$sql = "INSERT INTO complain (name,email,subject,message,date)
   VALUES ('$name','$email','$subject','$message','$current')";
  
  $result_insert=mysqli_query($conn,$sql);
	if($result_insert==true)
   {
	header("location:complain.php");
   }
   
 
 
?>
   
			 


				 
			 
			 


</body>

</html>
