<?php 
include ('connectfit.php');
session_start();


 ?>
<?php
 $selected_val = $_POST['days']; 
 $_SESSION["selected"] = $selected_val;
   if($selected_val=="monday" || $selected_val=="tuesday" || $selected_val=="wenesday" || $selected_val=="thursday" || $selected_val=="friday" || $selected_val=="saturday" ||$selected_val=="sunday")
   {
	   
	header("location:monday_detail.php");
   }
 
 
?>