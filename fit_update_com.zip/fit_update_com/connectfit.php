<?php
$host="localhost";
$user="root";
$pass="";
$databaseName = "fit";

 $conn=mysqli_connect($host,$user,$pass,$databaseName);
 
?>

