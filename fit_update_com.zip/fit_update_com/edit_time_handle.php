<?php include ('connectfit.php');?>
<?php


	session_start();


$id=$_SESSION["id"]; 
$food_time=$_POST['foodtime'];
$item = $_POST['itemname'];
$half_price= $_POST['halfprice'];
 $full_price=$_POST['fullprice'];
 
  $table_name=$_SESSION["admin_selected"]; 
 
  if($food_time=="BreakFast")
  {
   $sql = "UPDATE $table_name SET item='$item' ,half_price='$half_price',full_price='$full_price' WHERE id=$id";
  }
  else if($food_time=="Launch")
  {
   $sql = "UPDATE $table_name SET item_launch='$item' ,half_price_launch='$half_price',full_price_launch='$full_price' WHERE id=$id";
  }
  else  if($food_time=="Dinner")
  {
   $sql = "UPDATE $table_name SET item_dinner='$item' ,half_price_dinner='$half_price',full_price_dinner='$full_price' WHERE id=$id";
  }
	  
	  


if (mysqli_query($conn, $sql)) {
    echo "Record updated successfully";
	header ("location:admin_monday_detail.php");

} else {
    echo "Error updating record: " . mysqli_error($conn);
}

mysqli_close($conn);



?>