<?php 
include ('connectfit.php');



   session_start()

?>

 
 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <link rel="stylesheet" href="fitstyle.css">


 <style  type="text/css">
    
	
	
 </style>
		
		 </head>

            <body>

<div id="headertop1">
		<img id="logo" src="logo.png" width="120px" height="110px"></img>
		<text id="toptext">Namal College Mess Menu</text>
	
	</div>

<nav style="background-color:#183113;" class="navbar navbar-inverse">
  <div  style="margin-left:0px;"class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button> 
      
    </div>
  
   
    <div style="margin-left:0px;" class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" class="list-inline">
        <li style="color:red;margin-left:-60px;" class="active"><a href="home.php"><b>Home</b></a></li>
		
		<li clas="dropdown">
    <a href="#" data-toggle="dropdown" ><b>Admin</b></a>
    <ul class="dropdown-menu">
      <li><a href="admin_menu.php">check Record</a></li>
     <li><a href="add_menu.php">Add Menu</a></li>
	  <li><a href="view_complain.php">View Complain</a></li>
	   <li><a href="view_contact.php">View Contact</a></li>
    </ul></li>
    
       
	
		
	
       
         <li><a href="menu.php"><b>Menu</b></a></li>
       
       
      </ul>
	  <form class="navbar-form navbar-left">
      <div style="margin-left:200px;"class="input-group">
        <input type="text" class="form-control" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
	  
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home.php"><span class="glyphicon glyphicon-log-out"></span> <b>Logout</b></a></li>
      </ul>
    </div>
  </div>
</nav>
<?php

      $table_name=$_SESSION["admin_selected"]; 
	  $food_time;

?>
<div class="container">
<h2 style="margin-left:20%; margin-right:20%; text-align:center;">Menu</h2>
   <div style="margin-left:20%; margin-right:20%; background-color:#CDB99C;"  class="jumbotron">
  
  <form  method="post" action="admin_menu_handle.php" class="form-horizontal">
     
      
	 <div class="form-group">
	 <label class="control-label col-sm-4" >Select Day:</label>
	<select name="days" class ="form-control" style="margin-left:70px; width:240px; background-color:#BBBBBB;" class="col-sm-5 "  >
   <option value="monday">Monday</option>
   <option value="tuesday">Tuesday</option>
   <option value="wenesday">Wenesday</option>
  <option value="thursday">Thursday</option>
   <option value="friday">Friday</option>
   <option value="saturday">Saturday</option>
    <option value="sunday">Sunday</option>
        </select>

	 </div>
	 <br>
    <div class="form-group">        
      <div class="col-sm-offset-4 col-sm-10">
        <button type="Submit"  name="submit" class="btn-success">Submit</button>
      </div>
    </div>
  </form>
</div>
</div>
<br><br><br><br>
<div class="jumnotron">
<div  style="margin-left:40%; margin-right:40%; text-align:center; background-color:black; color:white;" class="well well-sm" ><?php echo $table_name?> Menu</div>
</div>
<div class="container">		
<div  style="margin-left:40%; margin-right:40%; text-align:center; background-color:#0000cc; color:white;" class="well well-sm" > BreakFast</div>
<table class="table table-striped">
 <thead style="background-color:#006600;">
<tr>

<th style="  border:1px  dotted; color:white;">Start Time</th>
<th style="  border:1px  dotted; color:white;">End Time</th>
<th style="  border:1px  dotted; color:white;">Update Time</th>
</tr>
</thead>

<?php
$sql="SELECT * FROM timetable WHERE id=5";
$query = mysqli_query($conn,$sql);

while($row_select= mysqli_fetch_array($query))
{

?>
<tr>
<td style=" border:1px  dotted;"><?=$row_select['fast_time_start']?> </td>
<td style=" border:1px  dotted;"><?=$row_select['fast_time_end']?></td>
<td style=" border:1px  dotted;" >
<a href="edit_time.php?id=<?=$row_select['id']?>"> <input type="button"
value="Edit"></a> </td>

</tr>

<?php
}
?>



</tbody>
</table>

<div style="background-color:#CDB99C;"class="jumbotron">
  <table  class="table table-bordered" >
<thead style="background-color:#006600;">
<tr>

<th style=" border:1px  dotted; color:white;">Item Name</th>
<th style=" border:1px  dotted; color:white;">Half Price</th>
<th style=" border:1px  dotted; color:white;">Full Price</th>
<th style=" border:1px  dotted; color:white;">Delete</th>
<th style=" border:1px  dotted; color:white;">Edit</th>
</tr>
</thead>

<tbody >
<?php
$break="BreakFast";
$sql="SELECT * FROM $table_name WHERE food_time LIKE '%".$break."%' ";
$query = mysqli_query($conn,$sql);
while($row_select= mysqli_fetch_array($query))
{

?>
<tr>
<td style=" border:1px  dotted; border-color:white; color:black;"><?=$row_select['item']?> </td>
<td style="border:1px  dotted; border-color:white; color:black;"><?=$row_select['half_price']?></td>
<td style="border:1px  dotted; border-color:white; color:black;"><?=$row_select['full_price']?></td>
  
<td style="border:1px  dotted; color:white;">
<a href="delete_data.php?id=<?=$row_select['id']?>" Onclick="check(this.value)"> <input type="button"
value="Delete"></a>
<td style="border:1px  dotted; color:white;">
<a href="edit_record.php?id=<?=$row_select['id']?>   "> <input type="button"
value="Edit"></a>
</tr>

<?php
}
?>
</tbody>
</table>
</div>
   </div>
  <div class="container">		
<div  style="margin-left:40%; margin-right:40%; text-align:center; background-color:#0000cc; color:white;" class="well well-sm" >Lunch</div>
 
 
 <table class="table table-striped">
 <thead style="background-color:#006600;">
<tr>

<th style=" border:1px  dotted; color:white;">Start Time</th>
<th style="  border:1px  dotted; color:white;">End Time</th>
<th style="  border:1px  dotted; color:white;">Update Time</th>
</tr>
</thead>

<?php
$sql="SELECT * FROM timetable WHERE id=5";
$query = mysqli_query($conn,$sql);

while($row_select= mysqli_fetch_array($query))
{

?>
<tr>
<td style="border:1px  dotted;"><?=$row_select['launch_time_start']?> </td>
<td style="border:1px  dotted;"><?=$row_select['launch_time_end']?></td>

<td style=" border:1px  dotted;" >
<a href="edit_time.php?id=<?=$row_select['id']?>"> <input type="button"
value="Edit"></a> </td>
</tr>

<?php
}
?>


</tbody>
</table>
<div style="background-color:#CDB99C;"  class="jumbotron">
  <table  class="table table-bordered" >
<thead style="background-color:#006600;">
<tr>

<th style=" border:1px  dotted; color:white;">Item Name</th>
<th style=" border:1px  dotted; color:white;">Half Price</th>
<th style=" border:1px  dotted; color:white;">Full Price</th>
<th style=" border:1px  dotted; color:white;">Delete</th>
<th style=" border:1px  dotted; color:white;">Edit</th>

</tr>
</thead>

<tbody >
<?php
$launch="Launch";
$sql="SELECT * FROM $table_name WHERE food_time LIKE '%".$launch."%' ";
$query = mysqli_query($conn,$sql);
while($row_select= mysqli_fetch_array($query))
{

?>
<tr>
<td style="border:1px  dotted; border-color:white; color:black;"><?=$row_select['item_launch']?> </td>
<td style="border:1px  dotted; border-color:white; color:black;"><?=$row_select['half_price_launch']?></td>
<td style="border:1px  dotted; border-color:white; color:black;"><?=$row_select['full_price_launch']?></td>
<td style="border:1px  dotted; border-color:white;">
<a href="delete_data.php?id=<?=$row_select['id']?>" Onclick="check(this.value)"> <input type="button"
value="Delete"></a>
<td style="border:1px  dotted; color:white;">
<a href="edit_record_launch.php?id=<?=$row_select['id']?>"> <input type="button"
value="Edit"></a>
</tr>

<?php
}
?>



</tbody>
</table>
</div>     
	</div>		 
 <div class="container">		
<div  style="margin-left:40%; margin-right:40%; text-align:center; background-color:#0000cc; color:white;" class="well well-sm" >Dinner</div>
<table class="table table-striped">
  <thead style="background-color:#006600;">
<tr>

<th style="  border:1px  dotted; color:white;">Start Time</th>
<th style="  border:1px  dotted; color:white;">End Time</th>
<th style="  border:1px  dotted; color:white;">Update Time</th>
</tr>
</thead>

<?php
$sql="SELECT * FROM timetable WHERE id=5";
$query = mysqli_query($conn,$sql);

while($row_select= mysqli_fetch_array($query))
{

?>
<tr>
<td style="border:1px  dotted;"><?=$row_select['dinner_time_start']?> </td>
<td style=" border:1px  dotted;"><?=$row_select['dinner_time_end']?></td>

<td style=" border:1px  dotted;">
<a href="edit_time.php?id=<?=$row_select['id']?>"> <input type="button"
value="Edit"></a> </td>
</tr>

<?php
}
?>



</tbody>
</table>
<div style="background-color:#CDB99C;"class="jumbotron">
 <table class="table table-striped">
<thead style="background-color:#006600;">
<tr>

<th style=" border:1px  dotted; color:white;">Item Name</th>
<th style=" border:1px  dotted; color:white;">Half Price</th>
<th style=" border:1px  dotted; color:white;">Full Price</th>
<th style=" border:1px  dotted; color:white;">Delete</th>
<th style=" border:1px  dotted; color:white;">Edit</th>

</tr>
</thead>

<tbody >
<?php
$break="Dinner";
$sql="SELECT * FROM $table_name WHERE food_time LIKE '%".$break."%' ";
$query = mysqli_query($conn,$sql);
while($row_select= mysqli_fetch_array($query))
{

?>
<tr>
<td style="border:1px  dotted; border-color:white; color:black;"><?=$row_select['item_dinner']?> </td>
<td style="border:1px  dotted; border-color:white; color:black;"><?=$row_select['half_price_dinner']?></td>
<td style="border:1px  dotted; border-color:white; color:black;"><?=$row_select['full_price_dinner']?></td>
<td style="border:1px  dotted; color:white;">
<a href="delete_data.php?id=<?=$row_select['id']?>" Onclick="check(this.value)"> <input type="button"
value="Delete"></a>
<td style="border:1px  dotted; color:white;">
<a href="edit_record_dinner.php?id=<?=$row_select['id']?>"> <input type="button"
value="Edit"></a>
</tr>

<?php
}
?>



</tbody>
</table>
</div>   
</div>
<!--Data Printing End-->
			 
<script>
function check(value) {
alert("Your Record has been deleted");

}
</script>			 
	
   <br><br><br><br>
   
	<div id="footer">
		<div class="followcontact">
		 <b>FOLLOW US ON<b>
			
		</div>
		<div  class="followcontact">
		<b>CONTACT INFO<b>	
		</div>
		<br><br><br><br><br><br>
		
		<div class="followuson">
			<a href="https://www.google.com.pk/search?q=facebook+namal+knowledge+city&oq=face&aqs=chrome.4.69i60j69i59l2j69i60j69i59j69i60.11179j0j7&sourceid=chrome&ie=UTF-8">
			<img id="facebook" src="facebook-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://twitter.com/namaledu?lang=en">
			<img id="twitter" src="twitter-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://vimeo.com/82274882">
			<img id="vimeo" src="vimeo-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://www.instagram.com/p/BD_bXBbEnLj/">
			<img id="instagram" src="instagram-128.png" width="40px" height="40px"></img>
			</a>
		</div>
		
		<div class="contactinfo">
			<div id="universityinfo">
				<img id="universityimg" style="margin-left:27px; margin-bottom:10px;"src="university.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">Namal College Mianwali</text>	
			<div>
			<div id="homeinfo">
				<img id="homeimg"   style="margin-left:27px; margin-bottom:10px;" src="home-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">30 Km Talagang Road, Mianwali, 42250, Pakistan</text>	
			<div>
			<div id="phoneinfo">
				<img id="phoneimg"  style="margin-left:27px; margin-bottom:10px; " src="phone-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">+92 (459) 236995</text>	
			<div>
			<div id="mailinfo">
				<img id="mailimg"  style="margin-left:27px;" src="mail-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">+92 (459) 236995</text>	
			<div>
			
			
		</div>
	</div> 	
		
			

</body>

</html>

