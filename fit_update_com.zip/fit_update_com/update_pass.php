<?php include ('connectfit.php');?>
<?php


	session_start();


$id=$_SESSION["id"]; 
$password=$_POST['password'];
$repassword= $_POST['repassword'];
$email= $_POST['email'];

 
  $table_name=$_SESSION["admin_selected"]; 
 
     if($password==$repassword)
	 {
   $sql = "UPDATE login SET email='$email' ,password='$password' WHERE id=1";
   if (mysqli_query($conn, $sql)) {
    echo "Record updated successfully";
	$_SESSION['update'] = ' your Password Updated please log in ';
	header ("location:sign-in.php");

} else {
    echo "Error updating record: " . mysqli_error($conn);
}
     mysqli_close($conn);
   
   } 
   else
   {    $_SESSION['error'] = 'Password do not  Match Re Enter';
	   header ("location:forget.php");
   }
       
  //if(isset)


//$password=$_POST['password'];
//$repassword= $_POST['repassword'];

//if(isset($_POST['submit'])){
//$selected_val = $_POST['zero'];  // Storing Selected Value In Variable
//echo "You have selected ";  // Displaying Selected Value



?>
