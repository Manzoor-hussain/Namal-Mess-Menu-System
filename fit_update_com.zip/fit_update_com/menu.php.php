<?php 
include ('conectdps.php');
session_start();


 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <link rel="stylesheet" href="dpstyle.css">


 <style  type="text/css">
    
	
	
 </style>
		
		 </head>

            <body>

<div style="background-color:#E51837; height:130px;"class="jumbotron">
  <div class="container text-center">
    <h6>GO Essay Cleaning Association</h6> 
	


   
  </div>
</div>

<!--<nav class="navbar navbar-inverse">-->
  <nav >
  <div  style="margin-left:30px;"class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button> 
      
    </div>
    <div style="margin-left:30px;" class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" class="list-inline">
        <li class="active"><a href="#"><b>Home</b></a></li>
		
		
       
	
		
    <li clas="dropdown">
    <a href="#" data-toggle="dropdown" ><b>Customer</b></a>
    <ul class="dropdown-menu">
      <li><a href="order.php">URGENT ORDER</a></li>
      <li><a href="complain.php">Complain</a></li>
      <li><a href="customer_detail.php">View Detail</a></li>
    </ul></li>
	
        <li><a href="#"><b>Products</b></a></li>
        <li><a href="#"><b>Deals</b></a></li>
        <li><a href="#"><b>Stores</b></a></li>
        <li><a href="#"><b>Contact</b></a></li>
      </ul>
	  <form class="navbar-form navbar-left">
      <div style="margin-left:150px;"class="input-group">
        <input type="text" class="form-control" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
	  
       <ul class="nav navbar-nav navbar-right">
        
        <li><a href="home.php"><span class="glyphicon glyphicon-log-out"></span> <b>Log out</b></a></li>
      </ul>
    </div>
  </div>
</nav>

   
<?php

       $email=$_SESSION["manzoor"]; 

?>
   
<div class="container">
<h2 style="margin-left:20%; margin-right:20%; ">Order Booking</h2>
  <div style="margin-left:20%; margin-right:20%; "  class="jumbotron">
  
  <form  method="post" action="order-record.php" class="form-horizontal">
     <div class="form-group">
      <label class="control-label col-sm-4" for="email">First Name:</label>
      <div class="col-sm-5" >
        <input type="text" class="form-control" id="name" name="fname" placeholder="Enter First Name"required >
      </div>
	  </div>
	  <div class="form-group">
      <label class="control-label col-sm-4" for="email">Last Name:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" id="lname"  name="lname" placeholder="Enter Last Name" required >
      </div>
	  </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="email">Email:</label>
      <div class="col-sm-5">
        <input type="email" class="form-control" value="<?php echo $email?>" name="email" placeholder="Enter email" required  >
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" >Address:</label>
      <div class="col-sm-5">          
        <input type="text" class="form-control"   name="address" placeholder="Enter Address" required>
      </div>
    </div>
       <div class="form-group">
      <label class="control-label col-sm-4" >Number of windows:</label>
      <div class="col-sm-5">          
        <input type="text" class="form-control" name="number" placeholder="Enter number of window" required  >
      </div>
    </div>
	 <div class="form-group">
	 <label class="control-label col-sm-4" >types of windows:</label>
	 <div class="col-sm-5"  class="dropdown" >
    <button style="width:220px;" class="btn btn-default dropdown-toggle"   name="size1" type="button" data-toggle="dropdown">2 X 2 feets
    <span class="caret"></span></button>
    <ul style="margin-left:13px;" name="size1" class="dropdown-menu">
      <li><a href="#">4 X 4 feets</a></li>
      <li><a href="#">5 X 5 feets</a></li>
      <li><a href="#">7 X 7 feets</a></li>
    </ul>
  </div>
	 </div>
	 <div class="form-group">
	 <label class="control-label col-sm-4" >types of windows:</label>
	 <select name="Make" class ="form-control" style="margin-left:70px; width:240px;" class="col-sm-5 "  >
   <option value="0">small</option>
   <option value="1">Medium</option>
   <option value="2">Large </option>
  
</select>

	 </div>
	 <br><br><br>
    <div class="form-group">        
      <div class="col-sm-offset-4 col-sm-10">
        <button type="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
</div>
</div>
	
 
 


<!--Data Printing End-->
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();   
});

</script>
<script>
$(document).ready(function(){

  var resultCountries = ['Germany', 'France', 'Spain'];

  $('[data-toggle="popover"]').popover({
    html: true,
    content: function() {
      var result = $();
      for (var i in resultCountries) {
        result = result.add(('<span>' + i + ' &ndash; ' + resultCountries[i] + '<span/><br/>'));
        console.log(i, resultCountries[i]);
      }
      return result;
    }

  });

});	




	 
			 
</script>			 
<br><br><br><br>
   
		<div id="footer"  class="container-fluid">
		 
		 
		 <nav class='block1'>
			<h4 style="margin-left:25px;" >Quick Links</h4>
			<ul type="circle">
			<li><a  href="https://www.facebook.com/profile.php?id=100007035996165"  class="block1-menu" >Services</a><br>
			<li><a  href=""  class="block1-menu">Complete Location List</a><br>
			<li><a  href=""   class="block1-menu">About Us</a><br>
			<li><a  href=""  class="block1-menu" >Photo Gally</a><br>
			<li><a  href=""  class="block1-menu">Links</a>
			<li><a  href=""  class="block1-menu">Contact US</a>
			</ul>
		</nav>
		 
		<nav class='block1'>
			<h4 style="margin-left:25px;">Information</h4>
			<ul type="circle">
			<li><a  href="https://www.facebook.com/profile.php?id=100007035996165"  class="block1-menu" >Giving Back</a><br>
			<li><a  href=""  class="block1-menu">Franchise Info</a><br>
			<li><a  href=""   class="block1-menu">Jobs</a><br>
			<li><a  href=""  class="block1-menu" >Terms of Use</a><br>
			<li><a  href=""  class="block1-menu">Privacy Policy </a>
			<li><a  href=""  class="block1-menu">Site Map</a>
			</ul>
		</nav>
	    
		 <nav class='block1'>
			<h4 style="margin-left:25px;">Information</h4>
			<ul type="circle">
			<li><a  href="https://www.facebook.com/profile.php?id=100007035996165"  class="block1-menu" >Giving Back</a><br>
			<li><a  href=""  class="block1-menu">Franchise Info</a><br>
			<li><a  href=""   class="block1-menu">Jobs</a><br>
			<li><a  href=""  class="block1-menu" >Terms of Use</a><br>
			<li><a  href=""  class="block1-menu">Privacy Policy </a>
			<li><a  href=""  class="block1-menu">Site Map</a>
			</ul>
		</nav>
		 </div>	 			 
		 
			

</body>

</html>
