<?php
include ('connectfit.php');
session_start();

$id=$_REQUEST['id'];


      $table_name=$_SESSION["admin_selected"]; 

   $_SESSION["id"] =$id;
  
  
$query_select="SELECT * FROM $table_name WHERE id='".$id."' LIMIT 1";
$results_select=mysqli_query($conn,$query_select);

$row_select= mysqli_fetch_array($results_select)
//echo "$food_time";
 ?>
 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <link rel="stylesheet" href="fitstyle.css">


 <style  type="text/css">
    
	
	
 </style>
		
		 </head>

            <body>

<div id="headertop1">
		<img id="logo" src="logo.png" width="120px" height="110px"></img>
		<text id="toptext">Namal College Mess Menu</text>
	
	</div>

<nav style="background-color:#183113;" class="navbar navbar-inverse">
  <div  style="margin-left:0px;"class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button> 
      
    </div>
  
   
    <div style="margin-left:0px;" class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" class="list-inline">
        <li style="color:red;margin-left:-60px;" class="active"><a href="home.php"><b>Home</b></a></li>
		
		<li clas="dropdown">
    <a href="#" data-toggle="dropdown" ><b>Admin</b></a>
    <ul class="dropdown-menu">
      <li><a href="admin_menu.php">check Record</a></li>
     <li><a href="add_menu.php">Add Menu</a></li>
	  <li><a href="view_complain.php">View Complain</a></li>
	   <li><a href="view_contact.php">View Contact</a></li>
    </ul></li>
    
       
	
		
	
       
         <li><a href="menu.php"><b>Menu</b></a></li>
       
        <li><a href="contact_us.php"><b>Contact</b></a></li>
      </ul>
	  <form class="navbar-form navbar-left">
      <div style="margin-left:200px;"class="input-group">
        <input type="text" class="form-control" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
	  
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home.php"><span class="glyphicon glyphicon-log-out"></span> <b>Logout</b></a></li>
      </ul>
    </div>
  </div>
</nav>
<br><br><br>

   
	
	<div class="container">
<h2 style="margin-left:20%; margin-right:20%; ">Edit Record</h2>
  <div style="margin-left:20%; margin-right:20%; "  class="jumbotron">
  
  <form  method="post"  class="form-horizontal" action="Update.php"   autocomplete="on"  enctype="multipart/form-data">
     
	
  

	 
	  <div class="form-group">
	 <label class="control-label col-sm-4" >Select Food Time:</label>
	 <div class="col-sm-5" >
        <input type="text" class="form-control"   value="<?=$row_select['food_time']?>" name="foodtime" placeholder="Enter Item Name"required >
	
         </div>

	 </div>
	 
     <div class="form-group">
      <label class="control-label col-sm-4" >Item Name:</label>
      <div class="col-sm-5" >
        <input type="text" class="form-control"   value="<?=$row_select['item_dinner']?>" name="itemname" placeholder="Enter Item Name"required >
      </div>
	  </div>
	  <div class="form-group">
      <label class="control-label col-sm-4" >Half Price:</label>
      <div class="col-sm-5">
        <input type="number" class="form-control"  value="<?=$row_select['half_price_dinner']?>" name="halfprice" min="5" step="5" max="50" placeholder="Enter half price in digit" required >
      </div>
	  </div>
    <div class="form-group">
      <label class="control-label col-sm-4" >Full Price:</label>
      <div class="col-sm-5">
        <input type="number" class="form-control" value="<?=$row_select['full_price_dinner']?>" name="fullprice" min="10" max="100" step="5" placeholder="Enter Full Price in degit" required  >
      </div>
    </div>
  
    <div class="form-group">        
      <div class="col-sm-offset-4 col-sm-8">
        <button type="submit" class="btn btn-default" onClick="check(this.value)" >Submit</button>
      </div>
    </div>
  </form>
</div>
</div>
	
	<script>
function check(value) {
alert("Your data Record has been updated ");

}
</script>		

	
    	
	 <br><br><br><br>
   
		<br><br><br><br>
   
	<div id="footer">
		<div class="followcontact">
		 <b>FOLLOW US ON<b>
			
		</div>
		<div  class="followcontact">
		<b>CONTACT INFO<b>	
		</div>
		<br><br><br><br><br><br>
		
		<div class="followuson">
			<a href="https://www.google.com.pk/search?q=facebook+namal+knowledge+city&oq=face&aqs=chrome.4.69i60j69i59l2j69i60j69i59j69i60.11179j0j7&sourceid=chrome&ie=UTF-8">
			<img id="facebook" src="facebook-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://twitter.com/namaledu?lang=en">
			<img id="twitter" src="twitter-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://vimeo.com/82274882">
			<img id="vimeo" src="vimeo-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://www.instagram.com/p/BD_bXBbEnLj/">
			<img id="instagram" src="instagram-128.png" width="40px" height="40px"></img>
			</a>
		</div>
		
		<div class="contactinfo">
			<div id="universityinfo">
				<img id="universityimg" style="margin-left:27px; margin-bottom:10px;"src="university.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">Namal College Mianwali</text>	
			<div>
			<div id="homeinfo">
				<img id="homeimg"   style="margin-left:27px; margin-bottom:10px;" src="home-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">30 Km Talagang Road, Mianwali, 42250, Pakistan</text>	
			<div>
			<div id="phoneinfo">
				<img id="phoneimg"  style="margin-left:27px; margin-bottom:10px; " src="phone-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">+92 (459) 236995</text>	
			<div>
			<div id="mailinfo">
				<img id="mailimg"  style="margin-left:27px;" src="mail-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">+92 (459) 236995</text>	
			<div>
			
			
		</div>
	</div> 	
      




</body>
</html>