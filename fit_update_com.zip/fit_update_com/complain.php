<?php 
include ('connectfit.php');



 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <link rel="stylesheet" href="dpstyle.css">


 <style  type="text/css">
    
	
	
 </style>
		
		 </head>

            <body>

 <div id="headertop1">
		<img id="logo" src="logo.png" width="120px" height="110px"></img>
		<text id="toptext">Namal College Mess Menu</text>
	
	</div>

<nav style="background-color:#183113;" class="navbar navbar-inverse">
  <div  style="margin-left:0px;"class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button> 
      
    </div>
  
   
    <div style="margin-left:0px;" class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" class="list-inline">
        <li style="color:red;margin-left:-60px;" ><a href="home.php"><b>Home</b></a></li>
		
		
       
	
		
	
       
         <li><a href="menu.php"><b>Menu</b></a></li>
       
        <li><a href="contact_us.php"><b>Contact</b></a></li>
		 <li><a href="complain.php" class="active"><b>Complain</b></a></li>
      </ul>
	  <form class="navbar-form navbar-left">
      <div style="margin-left:200px;"class="input-group">
        <input type="text" class="form-control" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
	  
      <ul class="nav navbar-nav navbar-right">
        <li><a href="sign-in.php"><span class="glyphicon glyphicon-log-in"></span> <b>Login</b></a></li>
      </ul>
    </div>
  </div>
</nav>
   <div class="container">
   <h2 style="margin-left:20%; margin-right:20%; " >Complain  </h2>
  <div style="margin-left:20%; margin-right:20%; " class="jumbotron">
  
  <form  method="post"  action="complain_handle.php "class="form-horizontal">
     <div class="form-group">
      <label class="control-label col-sm-4" for="email">Name:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control"  name="fname" placeholder="Enter First Name" required >
      </div>
	  </div>
	  
    <div class="form-group">
      <label class="control-label col-sm-4" for="email">Email:</label>
      <div class="col-sm-5">
        <input type="email" class="form-control"  name="email" placeholder="Enter email" required >
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-4" for="pwd">Subject:</label>
      <div class="col-sm-5">          
        <input type="text" class="form-control" name="subject" placeholder="Enter Your Subject" required >
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-4" for="pwd">Message:</label><br>
      <div class="col-sm-5">          
        <textarea  style="margin-left:1px;" rows="5" cols="28" value="" name="complain"   ></textarea>
      </div>
    </div>
    
    <div class="form-group">        
      <div class="col-sm-offset-4 col-sm-10">
        <button type="submit" class="btn btn-default"  >Submit</button>
      </div>
    </div>
  </form>
</div>
</div>     
<?php			 
 if(isset($_POST['submit'])){
//$selected_val = $_POST['time'];  // Storing Selected Value In Variable
echo "You have selected ";  // Displaying Selected Value
}	
?>
			 
			 
	<script>
function check(value) {
alert("Your complain has been submitted ");

}
</script>		
<br><br><br><br>
  <br><br><br><br>
   
	<div id="footer">
		<div class="followcontact">
		 <b>FOLLOW US ON<b>
			
		</div>
		<div  class="followcontact">
		<b>CONTACT INFO<b>	
		</div>
		<br><br><br><br><br><br>
		
		<div class="followuson">
			<a href="https://www.google.com.pk/search?q=facebook+namal+knowledge+city&oq=face&aqs=chrome.4.69i60j69i59l2j69i60j69i59j69i60.11179j0j7&sourceid=chrome&ie=UTF-8">
			<img id="facebook" src="facebook-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://twitter.com/namaledu?lang=en">
			<img id="twitter" src="twitter-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://vimeo.com/82274882">
			<img id="vimeo" src="vimeo-128.png" width="40px" height="40px"></img>
			</a>
			<a href="https://www.instagram.com/p/BD_bXBbEnLj/">
			<img id="instagram" src="instagram-128.png" width="40px" height="40px"></img>
			</a>
		</div>
		
		<div class="contactinfo">
			<div id="universityinfo">
				<img id="universityimg" style="margin-left:27px; margin-bottom:10px;"src="university.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">Namal College Mianwali</text>	
			<div>
			<div id="homeinfo">
				<img id="homeimg"   style="margin-left:27px; margin-bottom:10px;" src="home-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">30 Km Talagang Road, Mianwali, 42250, Pakistan</text>	
			<div>
			<div id="phoneinfo">
				<img id="phoneimg"  style="margin-left:27px; margin-bottom:10px; " src="phone-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">+92 (459) 236995</text>	
			<div>
			<div id="mailinfo">
				<img id="mailimg"  style="margin-left:27px;" src="mail-128.png" width="30px" height="30px"></img>
				<text class="contactcontenttext">+92 (459) 236995</text>	
			<div>
			
			
		</div>
	</div> 	
       
		
</body>

</html>
