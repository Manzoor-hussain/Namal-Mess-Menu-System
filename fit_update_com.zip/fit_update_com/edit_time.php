<?php
include ('connectfit.php');
session_start();

//$id=$_REQUEST['id'];


      $table_name=$_SESSION["admin_selected"]; 

  // $_SESSION["id"] =$id;
  $id=5;
  
$query_select="SELECT * FROM timetable WHERE id='".$id."' LIMIT 1";
$results_select=mysqli_query($conn,$query_select);

$row_select= mysqli_fetch_array($results_select)
//echo "$food_time";
 ?>
 
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <link rel="stylesheet" href="fitstyle.css">


 <style  type="text/css">
    
	
	
 </style>
		
		 </head>

            <body>

<div id="headertop1">
		<img id="logo" src="logo.png" width="120px" height="110px"></img>
		<text id="toptext">Namal College Mess Menu</text>
	
	</div>

<nav style="background-color:#183113;" class="navbar navbar-inverse">
  <div  style="margin-left:0px;"class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button> 
      
    </div>
  
   
    <div style="margin-left:0px;" class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav" class="list-inline">
        <li style="color:red;margin-left:-60px;" class="active"><a href="home.php"><b>Home</b></a></li>
		
		<li clas="dropdown">
    <a href="#" data-toggle="dropdown" ><b>Admin</b></a>
    <ul class="dropdown-menu">
      <li><a href="admin_menu.php">check Record</a></li>
     <li><a href="add_menu.php">Add Menu</a></li>
	  <li><a href="view_complain.php">View Complain</a></li>
    </ul></li>
    
       
	
		
	
       
         <li><a href="menu.php"><b>Menu</b></a></li>
       
        <li><a href="contact_us.php"><b>Contact</b></a></li>
      </ul>
	  <form class="navbar-form navbar-left">
      <div style="margin-left:200px;"class="input-group">
        <input type="text" class="form-control" placeholder="Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
        </div>
      </div>
    </form>
	  
      <ul class="nav navbar-nav navbar-right">
        <li><a href="home.php"><span class="glyphicon glyphicon-log-out"></span> <b>Logout</b></a></li>
      </ul>
    </div>
  </div>
</nav>
<br><br><br>

   
	
	<div class="container">
<h2 style="margin-left:20%; margin-right:20%; ">Edit Record</h2>
  <div style="margin-left:20%; margin-right:20%; "  class="jumbotron">
  
  <form  method="post"  class="form-horizontal" action="update_time.php"   autocomplete="on"  enctype="multipart/form-data">
     
	
  

	 
	  <div class="form-group">
	 <label class="control-label col-sm-4" >Select BreakFast Start Time:</label>
	 <div class="col-sm-5" >
        <input type="time" class="form-control"   value="<?=$row_select['fast_time_start']?>"  name="fasttimes"  placeholder="Enter Item Name"required >
	</div>
	</div>
	
	  <div class="form-group">
	 <label class="control-label col-sm-4" >Select BreakFast End Time:</label>
	 <div class="col-sm-5" >
        <input type="time" class="form-control"   value="<?=$row_select['fast_time_end']?>"  name="fasttimee"  placeholder="Enter Item Name"required >
	</div>
	</div>
	
	 
	  <div class="form-group">
	 <label class="control-label col-sm-4" >Select Launch Time Start:</label>
	 <div class="col-sm-5" >
        <input type="time" class="form-control"   value="<?=$row_select['launch_time_start']?>"  name="launchstart"  placeholder="Enter Item Name"required >
	</div>
	</div>
	
	  <div class="form-group">
	 <label class="control-label col-sm-4" >Select BreakFast Time End:</label>
	 <div class="col-sm-5" >
        <input type="time" class="form-control"   value="<?=$row_select['launch_time_end']?>"  name="launchend"  placeholder="Enter Item Name"required >
	</div>
	</div>
     <div class="form-group">
	 <label class="control-label col-sm-4" >Select Dinner Time Start:</label>
	 <div class="col-sm-5" >
        <input type="time" class="form-control"   value="<?=$row_select['dinner_time_start']?>"  name="dinnerstart"  placeholder="Enter Item Name"required >
	</div>
	</div>
	
	  <div class="form-group">
	 <label class="control-label col-sm-4" >Select BreakFast Time End:</label>
	 <div class="col-sm-5" >
        <input type="time" class="form-control"   value="<?=$row_select['dinner_time_end']?>"  name="dinnerend"  placeholder="Enter Item Name"required >
	</div>
	</div>
  
    <div class="form-group">        
      <div class="col-sm-offset-4 col-sm-8">
        <button type="submit" class="btn btn-default" onClick="check(this.value)" >Submit</button>
      </div>
    </div>
  </form>
</div>
</div>