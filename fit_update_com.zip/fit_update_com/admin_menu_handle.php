<?php 
include ('connectfit.php');

session_start();

 ?>
<?php

 $selected_val = $_POST['days']; 
 $_SESSION["admin_selected"] = $selected_val;
   if($selected_val=="monday" || $selected_val=="tuesday" || $selected_val=="wenesday" || $selected_val=="thursday" || $selected_val=="friday" || $selected_val=="saturday" ||$selected_val=="sunday")
   {
	   
	header("location:admin_monday_detail.php");
   }
 
?>